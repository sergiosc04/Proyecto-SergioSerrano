<script>
</script>
<template>
    <h1 align="center">Colección</h1>
    <p align="center">En construcción...</p>
</template>